                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2676324
bakercube by iomaa is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

<p>
Bakercube measuring cube</p>



# check out our binary carabiners

<p>
Check out our <a href="https://www.ebay.com/itm/Titanium-Binary-Carabiner-Safety-Cage-with-Bottle-Opener-EDC/232847177211?hash=item3636c5f5fb%3Am%3Amqhhml7CrqJVYmtZG_Dm5Ew&var=532368555047&_sacat=0&_nkw=binary+carabiner&_from=R40&rt=nc&_trksid=m570.l1313"> <strong>titanium binary key carabiners</a></strong> 
</p>


<p>
<strong>Features</strong>:
</p>
<ul>
<strong>
<li>Safety cage to keep your keys secure</li>
<li>Grade 5 Titanium body</li>
<li>Bottle opener</li>
<li>3 sizes</li>
<li>Finishes: bead blasted, stone, or polished</li>

</ul>

![Alt text](https://cdn.thingiverse.com/assets/22/f7/6d/09/a5/XXX.png)

# Our other thingiverse projects

<p>
<strong>
<a href="https://www.thingiverse.com/thing:2835728"> USB and SD holder</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2890504"> plug saver</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2711059"> clamps</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2856931"> coins</a></strong> |
<strong>
<a href="https://www.thingiverse.com/thing:2638683"> juice squeezer</a></strong> |
<strong>
<a href="https://www.thingiverse.com/iomaa/designs"> more...</a></strong>
</p>


![Alt text](https://cdn.thingiverse.com/assets/d6/ea/47/46/17/ba22.png)

# bakercube

<p>
<strong>…………………… </strong>
</p>

<p>
<strong><a href="https://www.youtube.com/watch?v=A8UnmNzpyEE">video</a></strong>


</p>



<p>
<strong>…………………… </strong>
</p>


<p>
<strong>bakercube</strong> | <strong>Version 3</strong> | Combined Imperial and Metric | includes in-line measurements of adjacent containers | 89 mm, 3.5" cube
</p>
<p>
<strong>Cups</strong>: 1 cup, 1/2 cup, 1/3 cup, 1/4 cup. <strong>Tablespoons</strong>: 2 tbsp, 1 tbsp, 1/2 tbsp | in-line: 3-1/2 tbsp, 3 tbsp, 2-1/2 tbsp, 1-1/2 tbsp. <strong>Teaspoons</strong>: 1 tsp, 1/2 tsp, 1/4 tsp | in-line: 1-3/4 tsp, 1-1/2 tsp, 3/4 tsp. <strong>Metric</strong>: 240 mL, 120 mL, 60 mL, 30 mL, 15 mL, 7.5 mL, 5 mL, 2.5 mL, 1.25 mL | in-line: 52.5 mL, 45 mL, 37.5 mL, 22.5 mL, 8.75 mL, 7.5 mL, 3.75 mL.
</p>

<p>
<strong>…………………… </strong>
</p>

<p>
<strong>bakercube</strong> | <strong>Version 2</strong>:
</p>
<p>
1 cup (236.588 mL), 1/2 cup, 1/3 cup, 1/4 cup, 1/8 cup, 1/4 teaspoon, 1/2 teaspoon, 1 teaspoon (4.928 mL), 1/2 tablespoon, 1 tablespoon. Size: 89 mm (3.5") cube.
</p>
<p></p>

<p>
<strong>…………………… </strong>
</p>


<p>
<strong>bakercube</strong> | <strong>Original</strong>:
</p>
<p>
1 cup (236.588 mL), 1/2 cup, 1/3 cup, 1/4 cup, 1/5 cup, 1/4 teaspoon, 1/2 teaspoon, 1 teaspoon (4.928 mL), 1 tablespoon. Size: 90 mm (3.5") cube.
</p>
<p></p>

<p>
<strong>…………………… </strong>
</p>

<p>
<strong>bakercube</strong> | <strong>Metric</strong>:
</p>
<p>
250 mL, 125 mL, 100 mL, 75 mL, 50 mL, 1/4 teaspoon, 1/2 teaspoon, 1 teaspoon (4.928 mL), 1 tablespoon. Size: 93 mm cube.
</p>
<p></p>
<p>
<strong>…………………… </strong>
</p>

<p>
<strong>MiniCube</strong>:
</p>
<p>
1/2 cup (118.294 mL), 1/3 cup, 1/4 cup, 1/16 teaspoon, 1/8 teaspoon, 1/4 teaspoon, 1/2 teaspoon, 1 teaspoon (4.928 mL), 2 teaspoons, 1/2 tablespoon, 1 tablespoon, 2 tablespoons. Size: 76 mm (3") cube.
</p>


<p>
<strong>…………………… </strong>
</p>
<p>
All containers share (within reason) common walls for the most compact shape and the minimum filament use.
</p>

<p>
How to use: fill all the way up for the correct volume for each container.
</p>

<p>
We printed at 0.1 mm layer, 12% fill, 0.2 mm layer should also be fine. Supports: NONE.
</p>

<p></p>

<p>
<strong>…………………… </strong>
</p>



<p></p>



<p>Enjoy</p>

<p>
<strong>…………………… </strong>
</p>



<p>
<strong>Make it in silicone</strong>: tbd, we need something solid, the winning material now is a compound commonly used in the food industry: it's extremely strong, survives the heat of a dishwasher, and it is FDA approved. It's much more expensive than a "regular" plastic, but well worth the price for the performance we need.
</p>
<p>
<strong>Make it in stainless</strong>: yes, after we reach break-even volumes in plastic. We don't want to get over our heads with separate production lines unless we have sufficient funds to control the process; startups are expensive. We already have a large number of stainless quotes, and we may introduce metals before the end of the campaign.
</p>
<p>
<strong>Cup size</strong>: my personal hell, with so many definitions of the cup. Good news: the difference between the “legal” and the “customary” US cup is around 1%, so whatever we choose it shouldn’t make a big difference. For cup definition enthusiasts: there are 20+ of them in use throughout the world; the current bakercube is using the best option to get started.
</p>
<p>
<strong>Larger cubes </strong>(I assume starting at 2 cups): sure, after we take care of the regular and the mini version.
</p>
<p>
<strong>Europe</strong>: yes, we’ll be shipping there.
</p>
<p>
<strong>Canada</strong>: Qui, bien sûr.
</p>
<p>
<strong>MiniCube</strong>: After it’s big brother is delivered, we need to take it one step at the time.
</p>
<p>
<strong>Volume Discounts</strong>: We'll offer volume discounts and early birds… with the shipping cost of multiple bakercubes close to the cost of shipping of a single bakercube.
</p>

<p>
<strong>Specs</strong>: Dishwasher safe, holds liquids, food grade, FDA safe, BPA-free... Yes, that's the plastic we selected, it's commonly used in the food industry.
</p>

<p>
<strong>Emails in the survey</strong>: we'll use them exclusively to let you know when the campaign is ready.
</p>

<p>
<strong>…………………… </strong>
</p>


The bakercube(TM) is protected by US patent pending.




https://www.youtube.com/watch?v=rRR7TU2lqPo


https://www.youtube.com/watch?v=zIshjS7lMz4


https://www.youtube.com/watch?v=gMdZ2zxTC4U


https://www.youtube.com/watch?v=emeuOKY9KPA


https://www.youtube.com/watch?v=tcQJkn1AKK4

https://www.youtube.com/watch?v=cRhB96lxmQo

https://www.youtube.com/watch?v=o2TWxKynqsg

https://www.youtube.com/watch?v=emeuOKY9KPA

https://youtu.be/o2TWxKynqsg

https://youtu.be/3zpJECnf30U

https://youtu.be/VBXIiQzLI-w


https://youtu.be/cRhB96lxmQo

https://youtu.be/BC7PmCXIlcc

https://youtu.be/VBXIiQzLI-w